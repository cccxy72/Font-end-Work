package com.cxy.travels.service;

import com.cxy.travels.entity.User;

public interface UserService {



    User login(User user);

    void register(User user);
}
