package com.cxy.travels.dao;

import com.cxy.travels.entity.Province;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface ProvinceDAO extends BaseDAO<Province,String> {


}
